#include <iostream>
#include <cmath>
#include <string>

using namespace std;

const int rows = 7;
const int columns = 7;

// FUNCTION TO PRINT THE GAME BOARD
void printBoard(char board[rows][columns]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

/// FUNCTION TO CHECK IF THE PLAYER WON AFTER EACH PLAY
// IT CHECKS FOR EVERY DIRECTION
bool checkWin(char player, char board[rows][columns]) {

    // HORIZONTAL
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j <= columns - 4; j++) {
            if (board[i][j] == player && board[i][j + 1] == player && board[i][j + 2] == player && board[i][j + 3] == player) {
                return true;
            }
        }
    }

    // VERTICAL
    for (int i = 0; i <= rows - 4; i++) {
        for (int j = 0; j < columns; j++) {
            if (board[i][j] == player && board[i + 1][j] == player && board[i + 2][j] == player && board[i + 3][j] == player) {
                return true;
            }
        }
    }

    // DIAGONAL (LEFT TO RIGHT)
    for (int i = 0; i <= rows - 4; i++) {
        for (int j = 0; j <= columns - 4; j++) {
            if (board[i][j] == player && board[i + 1][j + 1] == player && board[i + 2][j + 2] == player && board[i + 3][j + 3] == player) {
                return true;
            }
        }
    }

    // DIAGONAL (RIGHT TO LEFT)
    for (int i = 0; i <= rows - 4; i++) {
        for (int j = 3; j < columns; j++) {
            if (board[i][j] == player && board[i + 1][j - 1] == player && board[i + 2][j - 2] == player && board[i + 3][j - 3] == player) {
                return true;
            }
        }
    }
    return false;
}

// RESETS THE GAME BOARD FOR REPLAYABILITY
void resetBoard(char board[rows][columns]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            board[i][j] = '_';
        }
    }
}

/// /////////////////////////////////////////////////////////////////// AI FUNCTIONS //////////////////////////////////////////////////////////////////////

// AI WILL WIN 100% OF THE TIMES

// FUNCTION TO CHECK A POTENTIAL WINNING MOVE
bool potentialWinningMove(char player, char board[rows][columns], int column) {

    // MAKES A COPY OF THE BOARD
    char tempBoard[rows][columns];

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            tempBoard[i][j] = board[i][j];
        }
    }

    // CHECKS IF THE MOVE WOULD CONNECT 4
    for (int i = rows - 1; i >= 0; i--) {
        if (tempBoard[i][column] == '_') {
            tempBoard[i][column] = player;

            if (checkWin(player, tempBoard)) {
                return true; // IF A POTENTIAL WINNING MOVE WAS FOUND RETURNS TRUE
            }
            break;
        }
    }
    return false; // IF NOT RETURNS FALSE
}

// FUNCTION TO MAKE THE AI MOVE
void computerMove(char board[rows][columns], char computerSymbol) {

    // CHECKS FOR WINNING MOVES
    for (int col = 0; col < columns; col++) {
        if (potentialWinningMove(computerSymbol, board, col)) {

            // IF A WINNING MOVE IS FOUND, IT PLAYS THERE
            for (int i = rows - 1; i >= 0; i--) {
                if (board[i][col] == '_') {
                    board[i][col] = computerSymbol;
                    return;
                }
            }
        }
    }

    // CHECKS FOR POTENTIAL WINNING MOVES FOR THE PLAYER AND BLOCKS THEM
    char playerSymbol = (computerSymbol == 'X') ? 'O' : 'X';

    for (int col = 0; col < columns; col++) {
        if (potentialWinningMove(playerSymbol, board, col)) {

            // IF A WINNING MOVE FOR THE PLAYER IS FOUND, IT BLOCKS IT
            for (int i = rows - 1; i >= 0; i--) {
                if (board[i][col] == '_') {
                    board[i][col] = computerSymbol;
                    return;
                }
            }
        }
    }

    // IF NO POTENCIAL WINNING MOVES ARE FOUND, IT PICKS A RANDOM COLUMN
    int column;

    do {
        column = rand() % columns;
    } while (board[0][column] != '_');

    // MAKES A MOVE
    for (int i = rows - 1; i >= 0; i--) {
        if (board[i][column] == '_') {
            board[i][column] = computerSymbol;
            break;
        }
    }
}


int main() {
    // GAME BOARD
    char board[rows][columns] = {
        {'_', '_', '_', '_', '_', '_', '_'},
        {'_', '_', '_', '_', '_', '_', '_'},
        {'_', '_', '_', '_', '_', '_', '_'},
        {'_', '_', '_', '_', '_', '_', '_'},
        {'_', '_', '_', '_', '_', '_', '_'},
        {'_', '_', '_', '_', '_', '_', '_'}
    };

    // VARIABLES
    string player1, player2;
    char symbol1, symbol2;
    int language, answer, gamemode;

    // PLAYER VS AI ONLY
    char playerSymbol, computerSymbol;

    // LANGUAGE SELECTION LOOP
    do {
        cout << "Choose a language:" << endl << endl;
        cout << "Portugues - 1)" << endl;
        cout << "English - 2)" << endl;
        cout << "\nAnswer: ";

        cin >> language;

        if (language != 1 && language != 2) {
            system ("cls");
            cout << "Invalid character!" << endl << endl;
        }
    } while (language != 1 && language != 2);

    system ("cls"); // CLEAR SCREEN

    // GAMEMODE SELECTION LOOP
    do {
        // PORTUGUESE
        if (language == 1) {
            cout << "Escolha um modo de jogo:" << endl << endl;
            cout << "Jogador vs jogador - 1)" << endl;
            cout << "Jogador vs computador - 2)" << endl;
            cout << "\nResposta: ";

            cin >> gamemode;

        // ENGLISH
        } else {
            cout << "Choose a gamemode:" << endl << endl;
            cout << "Player vs player - 1)" << endl;
            cout << "Player vs AI - 2)" << endl ;
            cout << "\nAnswer: ";

            cin >> gamemode;
        }
    } while (gamemode != 1 && gamemode != 2);

    system("cls"); // CLEAR SCREEN

/// ////////////////////////////////////////////////////// PLAYER VS PLAYER /////////////////////////////////////////////////////////

    // GAME LOOP FOR REPLAYABILITY
    do {
        // CHECKS IF IT'S PLAYER VS PLAYER
        if (gamemode == 1) {

            system ("cls");

            if (language == 1) {
                cout << "\nBEM VINDO AO 4 EM LINHA!" << endl;

            } else {
                cout << "\nWELCOME TO CONNECT 4!" << endl;
            }

            // PLAYERS' NAMES LOOP
            do {
                if (language == 1) {
                    cout << "\nQual o nome do jogador 1? ";
                    cin >> player1;

                    cout << "Qual o nome do jogador 2? ";
                    cin >> player2;

                } else {
                    cout << "\nWhat's the name of player 1? ";
                    cin >> player1;

                    cout << "What's the name of player 2? ";
                    cin >> player2;
                }

                if (player1 == player2) {
                    if (language == 1) {
                        cout << "\nAmbos os jogadores nao podem ter o mesmo nome!\n";

                    } else {
                        cout << "\nBoth players can't have the same name!\n";
                    }
                }
            } while (player1 == player2);

            system("cls"); // CLEAR SCREEN

            // PLAYERS' SYMBOLS LOOP
            do {
                if (language == 1) {
                    cout << "\n" << player1 << ", escolha X ou O: ";

                } else {
                    cout << "\n" << player1 << ", choose X or O: ";
                }
                cin >> symbol1;

                if (symbol1 == 'X' || symbol1 == 'x') {
                    symbol1 = 'X';
                    symbol2 = 'O';

                } else if (symbol1 == 'O' || symbol1 == 'o') {
                    symbol1 = 'O';
                    symbol2 = 'X';

                } else {
                    if (language == 1) {
                        cout << "\nCaracter invalido!\n";

                    } else {
                        cout << "\nInvalid character!\n";
                    }
                }
            } while (symbol1 != 'X' && symbol1 != 'O');

            system("cls"); // CLEAR SCREEN

            /// MAIN GAME LOOP ///

            // VARIABLES
            bool gameOver = false;
            char currentPlayer = symbol1;

            while (!gameOver) {

                // PRINTS THE NAME AND THE SYMBOL OF BOTH PLAYERS
                cout << player1 << ": " << symbol1 << endl;
                cout << player2 << ": " << symbol2 << endl << endl;

                // PRINTS THE CURRENT BOARD
                printBoard(board);

                // ASKS THE USER INPUT
                int column;

                if (language == 1) {
                    cout << "\n" << (currentPlayer == symbol1 ? player1 : player2) << ", escolha uma coluna entre 1 e 7: ";

                } else {
                    cout << "\n" << (currentPlayer == symbol1 ? player1 : player2) << ", choose a column between 1 and 7: ";
                }
                cin >> column;

                // CHECKS IF THE COLUMN IS FREE/EXISTS
                if (column >= 1 && column <= 7) {
                    column--;

                    for (int i = rows - 1; i >= 0; i--) {
                        if (board[i][column] == '_') {
                            board[i][column] = currentPlayer;
                            system("cls"); // LIMPA TELA
                            break;
                        }
                    }
                } else {
                    system("cls"); // LIMPA TELA

                    if (language == 1) {
                        cout << "Coluna invalida! Escolha uma entre 1 e 7." << endl << endl;

                    } else {
                        cout << "Invalid column! Choose one between 1 and 7." << endl << endl;
                    }
                    continue;
                }

                // CHECKS IF THE PLAYER WON AFTER EACH PLAY
                if (checkWin(currentPlayer, board)) {

                    // PRINTS THE NAME AND THE SYMBOL OF BOTH PLAYERS
                    cout << player1 << ": " << symbol1 << endl;
                    cout << player2 << ": " << symbol2 << endl << endl;

                    printBoard(board);

                    if (language == 1) {
                        cout << "\nParabens! " << (currentPlayer == symbol1 ? player1 : player2) << " venceu!\n" << endl;

                    } else {
                        cout << "\nCongratulations! " << (currentPlayer == symbol1 ? player1 : player2) << " won!\n" << endl;
                    }
                    gameOver = true;

                } else {

                    // IF NOT, SWITCH TO THE NEXT PLAYER
                    currentPlayer = (currentPlayer == symbol1) ? symbol2 : symbol1;
                }
            }

        } else {

/// ////////////////////////////////////////////////////// PLAYER VS AI /////////////////////////////////////////////////////////

            if (language == 1) {
                cout << "\nQual o seu nome? ";

            } else {
                cout << "\nWhat's you name? ";
            }
            cin >> player1;

            system("cls"); // LIMPA TELA

            // PLAYER SYMBOL LOOP
            do {
                if (language == 1) {
                    cout << player1 << ", escolha X ou O: ";

                } else {
                    cout << player1 << ", choose X or O: ";
                }
                cin >> playerSymbol;

                if (playerSymbol == 'X' || playerSymbol == 'x') {
                    playerSymbol = 'X';
                    computerSymbol = 'O';

                } else if (playerSymbol == 'O' || playerSymbol == 'o') {
                    playerSymbol = 'O';
                    computerSymbol = 'X';

                } else {
                    cout << "\nInvalid character!\n";
                }

            } while (playerSymbol != 'X' && playerSymbol != 'O');

            system("cls"); // CLEAR SCREEN

            /// MAIN GAME LOOP

            bool gameOver = false;
            bool playerTurn = true;

            // PRINTS THE USER'S SYMBOL AND AI'S SYMBOL
            cout << player1 << ": " << playerSymbol << endl;

            if (language == 1){
                cout << "Computador: " << computerSymbol << endl << endl;

            } else {
                cout << "Computer: " << computerSymbol << endl << endl;

            }

            while (!gameOver) {

                // CLEAR SCREEN TO SHOW ONLY ONE BOARD AT A TIME
                system("cls");

                // PLAYER'S TURN
                if (playerTurn) {
                    if (language == 1) {
                        cout << "Sua vez: " << endl;

                    } else {
                        cout << "Your turn: " << endl;
                    }

                    printBoard(board);

                    // ASKS THE PLAYER FOR THEIR POSITION
                    int column;

                    if (language == 1) {
                        cout << "Escolha uma coluna entre 0 e 6: ";

                    } else {
                        cout << "Choose a column between 0 and 6: ";
                    }

                    cin >> column;

                    // CHECKS IF THE CHOSEN COLUMN IS VALID
                    if (column < 0 || column >= columns || board[0][column] != '_') {
                        if (language == 1) {
                            cout << "Coluna invalida! Escolha uma entre 0 e 6." << endl << endl;

                        } else {
                            cout << "Invalid column! Choose one between 0 and 6." << endl << endl;
                        }
                        continue;
                    }

                    // PRINTS THE PLAYER'S MOVE
                    for (int i = rows - 1; i >= 0; i--) {
                        if (board[i][column] == '_') {
                            board[i][column] = playerSymbol;
                            break;
                        }
                    }

                    // CHECKS IF THE PLAYER WON
                    if (checkWin(playerSymbol, board)) {
                        gameOver = true;
                        if (language == 1) {
                            cout << "Parabens! Ganhas-te!" << endl;

                        } else {
                            cout << "Congratulations! You win!" << endl;
                        }
                        continue;
                    }

                // AI'S TURN
                } else {
                    if (language == 1) {
                        cout << "Vez do computador:\n";

                    } else {
                        cout << "Computer's turn:\n";
                    }

                    // MAKES THE AI MOVE
                    computerMove(board, computerSymbol);

                    printBoard(board); // PRINTS THE BOARD WITH THE AI MOVES

                    // CHECKS IF THE COMPUTER WON
                    if (checkWin(computerSymbol, board)) {
                        gameOver = true;
                        if (language == 1) {
                            cout << "O computador ganhou! Boa sorte para a proxima.\n";

                        } else {
                            cout << "Computer wins! Better luck next time.\n";
                        }
                    }
                }

                // SWITCHES TURNS
                playerTurn = !playerTurn;
            }

        }

/// ////////////////////////////////////////////////////// POST GAME OPTIONS /////////////////////////////////////////////////////////

        // ASKS THE USER IF THEY WANT TO REPLAY THE GAME OR CLOSE THE APP

        if (language == 1) {
            cout << "Jogar de novo - 1)" << endl;
            cout << "Fechar programa - 2)" << endl;
            cout << "Resposta: ";

        } else {
            cout << "Replay - 1)" << endl;
            cout << "Close app - 2)" << endl;
            cout << "Answer: ";
        }

        cin >> answer;

        resetBoard(board); // RESETS THE GAME BOARD FOR REPLAYABILITY

    } while (answer != 2);

    return 0;
}
