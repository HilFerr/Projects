Connect 4

------------
Installation
------------

Follow the steps to install and run this program.

1. Download the files;
2. Upload them to your favorite IDE: File > Open > 4 em linha.cpp;
3. Execute the file and play.

--------
Gameplay
--------

Version 1.0

How the game should run:

1. Ask the user for a language, either Portuguese or English;
2. Ask which gamemode the user wants to play, either Player vs Player or Player vs AI;
3. Ask the user for the username for both player;
4. Ask the player 1 for their symbol (X or O);
5. Show the Game Board and allow the player to play;
6. PvP: Once a player connect's 4 the game should end, with the player that connected being the winner.
6. PvAI: The player cannot win against the AI, as the AI will calculate if the player is almost connecting 4 and will block so that doesn't happen.
7. Have fun!